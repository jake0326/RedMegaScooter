JS Playground
=============
Collection of my Javascript experiments, mostly published on codepen.io. Feel free to use the source code as you wish.

Demos:
=============
* Canvas Asteroids: http://codepen.io/everblind/details/bzBsp

License
=============
Copyright (c) Jeff Ibacache. See the LICENSE file for license rights and limitations (MIT).