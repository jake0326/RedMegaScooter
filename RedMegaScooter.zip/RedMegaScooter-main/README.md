# Welcome to RedMegaScooter
Welcome to RedMegaScooter, this website was made for a capstone project at Portage Lakes Career Center in Cyber Academy in the year 2021.

We decided to make a teaching website. It teaches computer programming and computer networking. We also added some things for amusement purposes. Play a few games to try learn how they work. Want to learn about something specific? Go to the section you want to learn more about and select the specialty. Make sure to have fun and have a nice day.
