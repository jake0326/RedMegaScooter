module.exports = {
  entry: "./lib/space_invaders.js",
  output: {
  	filename: "./bundle.js"
  },
  devtool: 'source-map'
};
